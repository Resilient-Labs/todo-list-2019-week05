let submitButton = document.getElementById('submit');
let toDoInput = document.getElementById('toDoInput')
let toDoList = document.getElementById('toDoList')
let form = document.getElementById('#newtask')
let clearButton = document.getElementById('clear')
let clearCompletedTask = document.getElementById('cct')
let leftOver = document.getElementById('leftOver')


function inputLength() {
    return toDoInput.value.length;
  }
toDoInput.addEventListener('keypress', function(event){
        if(event.keyCode == 13) {
            submitButton.click()
        }
         
})

submitButton.addEventListener('click',function(e) {
    e.preventDefault()
    if(document.querySelector('#toDoInput').value.length == 0){
        alert("Please Enter A Task");
        return 
    } 
    
    const li = document.createElement('li');
    li.innerText = toDoInput.value;
    toDoInput.value = "";
    toDoList.appendChild(li);
    li.addEventListener('click', () => {
        li.classList.toggle('done')
        tasksUp()
    })  
})
   
function tasksUp(){
    let everyTask = document.querySelectorAll('li').length
    let clearCompletedTask = document.querySelectorAll('.done').length
    console.log(everyTask, clearCompletedTask)
        leftOver.innerText = (everyTask - clearCompletedTask)
}

function clearCompleted(){
    console.log('clearCompleted')
    let done = document.getElementsByClassName('done')
    for(let i = 0; i < done.length; i++){
        done[i].style.display = 'none'
    }
    console.log(clearCompletedTask)
    tasksUp()
}
function clear(){
    document.getElementById("toDoList").innerText = ("");
    tasksUp();
}



clearButton.addEventListener('click', clear)
clearCompletedTask.addEventListener('click', clearCompleted)


// function clearButt(){
//     listMe.innerHTML = ""
//     tasksUp()
// }

